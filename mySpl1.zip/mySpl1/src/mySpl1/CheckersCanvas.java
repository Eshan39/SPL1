package mySpl1;

import java.awt.Button;
import java.awt.Canvas;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Label;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

class CheckersCanvas extends Canvas implements ActionListener, MouseListener {

	    
	   Button resignButton;   
	   Button newGameButton;   
	   
	   Label message;   
	   
	   Checkers board;  

	   boolean gameInProgress;
	   
	   int currentPlayer;      
	   int selectedRow, selectedCol;  
	   CheckersMove[] legalMoves;  
	   

	   public CheckersCanvas() {
	         
	      setBackground(Color.black);
	      addMouseListener(this);
	      setFont(new  Font("Serif", Font.BOLD, 14));
	      resignButton = new Button("Resign");
	      resignButton.addActionListener(this);
	      newGameButton = new Button("New Game");
	      newGameButton.addActionListener(this);
	      message = new Label("",Label.CENTER);
	      board = new Checkers();
	      doNewGame();
	   }
	   

	   public void actionPerformed(ActionEvent evt) {
	         
	      Object src = evt.getSource();
	      if (src == newGameButton)
	         doNewGame();
	      else if (src == resignButton)
	         doResign();
	   }
	   

	   void doNewGame() {
	         // Begin a new game.
	      if (gameInProgress == true) {
	             
	         message.setText("Finish the current game first!");
	         return;
	      }
	      
	      board.setUpGame();  
	      
	      currentPlayer = Checkers.WHITE;   
	      legalMoves = board.allValidMoves(Checkers.WHITE);  
	      selectedRow = -1;   // White has not yet selected a piece to move.
	      message.setText("WHITE:  Make your move.");
	      gameInProgress = true;
	      newGameButton.setEnabled(false);
	      resignButton.setEnabled(true);
	      repaint();
	   }
	   

	   void doResign() {
	          
	       if (gameInProgress == false) {
	          message.setText("There is no game in progress!");
	          return;
	       }
	       if (currentPlayer == Checkers.WHITE)
	          gameOver("WHITE resigns.  BLACK wins.");
	       else
	          gameOver("BLACK resigns.  WHITE wins.");
	   }
	   

	   void gameOver(String str) {
	          
	      message.setText(str);
	      newGameButton.setEnabled(true);
	      resignButton.setEnabled(false);
	      gameInProgress = false;
	   }
	      

	   void doClickSquare(int row, int col) {
	       

	      for (int i = 0; i < legalMoves.length; i++)
	         if (legalMoves[i].startRow == row && legalMoves[i].startCol == col) {
	            selectedRow = row;
	            selectedCol = col;
	            if (currentPlayer == Checkers.WHITE)
	               message.setText("WHITE:  Make your move.");
	            else
	               message.setText("BLACK:  Make your move.");
	            repaint();
	            return;
	         }

	      

	      if (selectedRow < 0) {
	          message.setText("Click the piece you want to move.");
	          return;
	      }
	      
	     

	      for (int i = 0; i < legalMoves.length; i++)
	         if (legalMoves[i].startRow == selectedRow && legalMoves[i].startCol == selectedCol
	                 && legalMoves[i].endRow == row && legalMoves[i].endCol == col) {
	            doMakeMove(legalMoves[i]);
	            return;
	         }
	         
	     
	      message.setText("Click the square you want to move to.");

	   }  
	   

	   void doMakeMove(CheckersMove move) {
	          
	      board.makeMove(move);
	      
	     
	      
	      if (move.isJump()) {
	         legalMoves = board.allJumpMove(currentPlayer,move.endRow,move.endCol);
	         if (legalMoves != null) {
	            if (currentPlayer == Checkers.WHITE)
	               message.setText("WHITE:  You must continue jumping.");
	            else
	               message.setText("BLACK:  You must continue jumping.");//use alpha beta
	            selectedRow = move.endRow; 
	            selectedCol = move.endCol;
	            repaint();
	            return;
	         }
	      }
	      
	      
	      
	      if (currentPlayer == Checkers.WHITE) {
	         currentPlayer = Checkers.BLACK;
	         legalMoves = board.allValidMoves(currentPlayer);//alpha beta
	         for(int i=0; i<legalMoves.length;i++) {
	        	 System.out.println(legalMoves[i]);
	         }
	         if (legalMoves == null)
	            gameOver("BLACK has no moves. WHITE wins.");
	         else if (legalMoves[0].isJump())
	            message.setText("BLACK:  Make your move.  You must jump.");
	         else
	            message.setText("BLACK:  Make your move.");
	      }
	      else {
	         currentPlayer = Checkers.WHITE;
	         legalMoves = board.allValidMoves(currentPlayer);
	         if (legalMoves == null)
	            gameOver("WHITE has no moves.  BLACK wins.");
	         else if (legalMoves[0].isJump())
	            message.setText("WHITE:  Make your move.  You must jump.");
	         else
	            message.setText("WHITE:  Make your move.");
	      }
	      
	      /* Set selectedRow = -1 to record that the player has not yet selected
	          a piece to move. */
	      
	      selectedRow = -1;
	      
	      
	      
	      if (legalMoves != null) {
	         boolean sameStartSquare = true;
	         for (int i = 1; i < legalMoves.length; i++)
	            if (legalMoves[i].startRow != legalMoves[0].startRow
	                                 || legalMoves[i].startCol != legalMoves[0].startCol) {
	                sameStartSquare = false;
	                break;
	            }
	         if (sameStartSquare) {
	            selectedRow = legalMoves[0].startRow;
	            selectedCol = legalMoves[0].startCol;
	         }
	      }
	      
	      
	      
	      repaint();
	      
	   }  // end doMakeMove();
	   

	   public void update(Graphics g) {
	        
	      paint(g);
	   }
	   

	   public void paint(Graphics g) {
	        
	      g.setColor(Color.black);
	      g.drawRect(0,0,getSize().width,getSize().height);
	      g.drawRect(1,1,getSize().width,getSize().height);
	      
	     
	      
	      for (int row = 0; row < 8; row++) {
	         for (int col = 0; col < 8; col++) {
	             if ( row % 2 == col % 2 )
	        	// if ( row % 2 !=0)
	                g.setColor(Color.lightGray);
	             else
	                g.setColor(Color.gray);
	             g.fillRect(8 + col*80, 8 + row*80, 80, 80);
	             switch (board.pieceAt(row,col)) {
	                case Checkers.WHITE:
	                   g.setColor(Color.red);
	                   g.fillOval(16 + col*80, 16 + row*80, 64, 64);
	                   break;
	                case Checkers.BLACK:
	                   g.setColor(Color.black);
	                   g.fillOval(16 + col*80, 16 + row*80, 64, 64);
	                   break;
	                case Checkers.WHITE_KING:
	                   g.setColor(Color.red);
	                   g.fillOval(16 + col*80, 16 + row*80, 64, 64);
	                   g.setColor(Color.white);
	                   g.drawString("K", 28 + col*80, 64 + row*80);
	                   break;
	                case Checkers.BLACK_KING:
	                   g.setColor(Color.black);
	                   g.fillOval(16 + col*80, 16 + row*80, 64, 64);
	                   g.setColor(Color.white);
	                   g.drawString("K", 28 + col*80, 64 + row*80);
	                   break;
	             }
	         }
	      }
	    
	      
	      if (gameInProgress) {
	            
	         g.setColor(Color.cyan);
	         for (int i = 0; i < legalMoves.length; i++) {
	            g.drawRect(8 + legalMoves[i].endCol*80, 8 + legalMoves[i].startRow*80, 76, 76);
	         }
	            
	         if (selectedRow >= 0) {
	            g.setColor(Color.white);
	            g.drawRect(8 + selectedCol*80, 8 + selectedRow*80, 76, 76);
	            g.drawRect(12 + selectedCol*80, 12 + selectedRow*80, 68, 68);
	            g.setColor(Color.green);
	            for (int i = 0; i < legalMoves.length; i++) {
	               if (legalMoves[i].startCol == selectedCol && legalMoves[i].startRow == selectedRow)
	                  g.drawRect(8 + legalMoves[i].endCol*80, 8 + legalMoves[i].startRow*80, 76, 76);
	            }
	         }
	      }
	   }  // end paint()
	   
	   
	   public Dimension getPreferredSize() {
	        
	      return new Dimension(656,656);
	   }


	   public Dimension getMinimumSize() {
	      return new Dimension(656,656);
	   }
	   

	   public void mousePressed(MouseEvent evt) {
	         
	      if (gameInProgress == false)
	         message.setText("Click \"New Game\" to start a new game.");
	      else {
	         int col = (evt.getX() - 8) / 80;
	         int row = (evt.getY() - 8) / 80;
	         if (col >= 0 && col < 8 && row >= 0 && row < 8)
	            doClickSquare(row,col);
	      }
	   }
	   

	   public void mouseReleased(MouseEvent evt) { }
	   public void mouseClicked(MouseEvent evt) { }
	   public void mouseEntered(MouseEvent evt) { }
	   public void mouseExited(MouseEvent evt) { }


	}  

