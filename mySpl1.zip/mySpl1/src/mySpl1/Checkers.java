package mySpl1;

import java.util.Vector;

public class Checkers {
	
	public static final int SIZE=8;
	public static final int
    			EMPTY = 0,
    			WHITE = 1,
    			WHITE_KING = 2,
    			BLACK = 3,
    			BLACK_KING = 4;

	public int[][] board;
	
	public Checkers()
	{
		board=new int[SIZE][SIZE];
		
		setUpGame();
		//board.toString();
		
	}
	
	public void setUpGame() {
        
		for(int i=0;i<SIZE;i++)
		{
			for(int j=0;j<SIZE;j++)
			{
				if(i%2==j%2)
				//if(i%2!=0)
				{
					if(i<=2) 
						board[i][j]=WHITE;
					else if(i>=5)
						board[i][j]=BLACK;
					else
						board[i][j]=EMPTY;
				}
				else 
					board[i][j]=EMPTY;
			}
		}
	}  // end setUpGame()
 
	 public void makeMove(CheckersMove move) {

		 makeMove(move.startRow, move.startCol, move.endRow, move.endCol);
    }
	
	public void makeMove(int startRow, int startCol, int endRow, int endCol) {
		
		board[endRow][endCol] = board[startRow][startCol];
		board[startRow][startCol] = EMPTY;
		
		if (startRow - endRow == 2 || startRow - endRow == -2) {
    	   int skipRow = (startRow + endRow) / 2; 
    	   int skipCol = (startCol + endCol) / 2;
    	   board[skipRow][skipCol] = EMPTY;
		}
		
		if (endRow == 0 && board[endRow][endCol] == BLACK)
    	  board[endRow][endCol] = BLACK_KING;
		if (endRow == SIZE-1 && board[endRow][endCol] == WHITE)
    	  board[endRow][endCol] = WHITE_KING;
	}
	
	
	
	public CheckersMove[] allValidMoves(int player) {
        
   // if (player != WHITE && player != BLACK)
       //return null;

    int playerKing; 
    if (player == WHITE)
       playerKing = WHITE_KING;
    else
       playerKing = BLACK_KING;

    Vector moves = new Vector();  
    
    for (int row = 0; row < SIZE; row++)
    {
       for (int col = 0; col < SIZE; col++)
       {
          if (board[row][col] == player || board[row][col] == playerKing)
          {
        	  
             if (conditionForJump(player, row, col, row+1, col+1, row+2, col+2))
                moves.addElement(new CheckersMove(row, col, row+2, col+2));
             
             if (conditionForJump(player, row, col, row-1, col+1, row-2, col+2))
                moves.addElement(new CheckersMove(row, col, row-2, col+2));
             
             if (conditionForJump(player, row, col, row+1, col-1, row+2, col-2))
                moves.addElement(new CheckersMove(row, col, row+2, col-2));
             
             if (conditionForJump(player, row, col, row-1, col-1, row-2, col-2))
                moves.addElement(new CheckersMove(row, col, row-2, col-2));
          
          }
       }
    }
    
    if (moves.size() == 0)
    {
    	
       for (int row = 0; row < SIZE; row++)
       {
    	   
          for (int col = 0; col < SIZE; col++)
          {
        	  
             if (board[row][col] == player || board[row][col] == playerKing)
             {
            	 
                if (conditionForMove(player,row,col,row+1,col+1))
                   moves.addElement(new CheckersMove(row,col,row+1,col+1));
                
                if (conditionForMove(player,row,col,row-1,col+1))
                   moves.addElement(new CheckersMove(row,col,row-1,col+1));
                
                if (conditionForMove(player,row,col,row+1,col-1))
                   moves.addElement(new CheckersMove(row,col,row+1,col-1));
                
                if (conditionForMove(player,row,col,row-1,col-1))
                	moves.addElement(new CheckersMove(row,col,row-1,col-1));
                
             }
          }
       }
    }
    
    

    if (moves.size() == 0)
       return null;
    
    else {
    	
       CheckersMove[] move = new CheckersMove[moves.size()];
       for (int i = 0; i < moves.size(); i++)
          move[i] = (CheckersMove)moves.elementAt(i);
       
       
       return move;
    }

 }  
 
	
	 public CheckersMove[] allJumpMove(int player, int row, int col) {
        
		 if (player != WHITE && player != BLACK)
			 return null;
		 int playerKing;  
		 if (player == WHITE)
			 playerKing = WHITE_KING;
		 else
			 playerKing = BLACK_KING;
		 
		 Vector moves = new Vector();
      
      if (board[row][col] == player || board[row][col] == playerKing)
      {
         if (conditionForJump(player, row, col, row+1, col+1, row+2, col+2))
        	 moves.addElement(new CheckersMove(row, col, row+2, col+2));
         
         if (conditionForJump(player, row, col, row-1, col+1, row-2, col+2))
        	 moves.addElement(new CheckersMove(row, col, row-2, col+2));
         
         if (conditionForJump(player, row, col, row+1, col-1, row+2, col-2))
        	 moves.addElement(new CheckersMove(row, col, row+2, col-2));
         
         if (conditionForJump(player, row, col, row-1, col-1, row-2, col-2))
        	 moves.addElement(new CheckersMove(row, col, row-2, col-2));
      }
      
      if (moves.size() == 0)
         return null;
      else {
         CheckersMove[] move = new CheckersMove[moves.size()];
         for (int i = 0; i < moves.size(); i++)
            move[i] = (CheckersMove)moves.elementAt(i);
         return move;
      }
   }  
	private boolean conditionForMove(int player, int r1, int c1, int r2, int c2) {
         
      if (r2 < 0 || r2 >= 8 || c2 < 0 || c2 >= 8)
         return false; 
         
      if (board[r2][c2] != EMPTY)
         return false; 

      if (player == WHITE) {
         if (board[r1][c1] == WHITE && r1 > r2)
             return false; 
          return true;  
      }
      else {
         if (board[r1][c1] == BLACK && r2 > r1)
             return false; 
          return true; 
      }
      
   } 
	private boolean conditionForJump(int player, int r1, int c1, int r2, int c2, int r3, int c3) {
     
		if (r3 < 0 || r3 >= 8 || c3 < 0 || c3 >= 8)
			return false;
       
		if (board[r3][c3] != EMPTY)
			return false;  
       
		if (player == WHITE) {
			if (board[r1][c1] == WHITE && r1 > r3)
				return false;
			if (board[r2][c2] != BLACK && board[r2][c2] != BLACK_KING)
				return false; 
			return true;  
		}
		else {
			if (board[r1][c1] == BLACK && r3 > r1)
				return false;  
			if (board[r2][c2] != WHITE && board[r2][c2] != WHITE_KING)
				return false;  
			return true;  
		}

	}  
	
	 public int getPieceAt(int row, int col) {
     
		 return board[row][col];
		 
	 }
  

	 public void setPieceAt(int row, int col, int piece) {
		 
		 board[row][col] = piece;
	 }
	 
	 public String toString() {
	        StringBuilder build = new StringBuilder();
	        build.append(" Board ");
	        for (int i = 0; i < SIZE; i++) {
	            build.append("	");
	        }
	        build.append("\n");
	        for (int i = 0; i < SIZE; i++) {
	            for (int j = -1; j < SIZE; j++) {
	                String add = "";
	                if (j == -1)
	                    add = "";
	                else if (board[i][j] == WHITE)
	                    add = " w ";
	                else if (board[i][j] == BLACK)
	                    add = " b ";
	                else if (board[i][j] == WHITE_KING)
	                    add = " W ";
	                else if (board[i][j] == BLACK_KING)
	                    add = " B ";
	                else
	                    add = " _ ";

	                build.append(add);
	                build.append(" ");
	            }
	            build.append("\n");
	        }
	        return build.toString();
	    }
	 public int pieceAt(int row, int col) {
         
      return board[row][col];
      
	 }
  
	
}
