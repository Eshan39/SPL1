package mySpl1;

public class CheckersMove {
	
    
	   int startRow, startCol;  
	   int endRow, endCol;      
	   public CheckersMove(int r1, int c1, int r2, int c2) {
	      startRow = r1;
	      startCol = c1;
	      endRow = r2;
	      endCol = c2;
	      
	    //  System.out.println("Eshan");
	   }
	   
	   boolean isJump() {
	        
	      return (startRow - endRow == 2 || startRow - endRow == -2);
	   }
	  
}  