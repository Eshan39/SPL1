package mySpl1;

import java.applet.Applet;
import java.awt.Button;
import java.awt.Color;
import java.awt.Font;
import java.awt.Label;

//import class2.CheckersCanvas;

public class MainClass extends Applet {

	public	void init() {
			   
		      setLayout(null);  
		   
		      setBackground(new Color(0,150,0));  

		      CheckersCanvas board = new CheckersCanvas();
		         
		      add(board);

		      board.newGameButton.setBackground(Color.lightGray);
		      add(board.newGameButton);

		      board.resignButton.setBackground(Color.lightGray);
		      add(board.resignButton);

		      board.message.setForeground(Color.green);
		      board.message.setFont(new Font("Serif", Font.BOLD, 14));
		      add(board.message);
		      
		    
		      board.setBounds(10,10,656,656); // Note:  size MUST be 164-by-164 !
		      board.newGameButton.setBounds(700, 60, 100, 30);
		      board.resignButton.setBounds(700, 120, 100, 30);
		      board.message.setBounds(700, 180, 330, 30);
		   
		   
	}

	

}
